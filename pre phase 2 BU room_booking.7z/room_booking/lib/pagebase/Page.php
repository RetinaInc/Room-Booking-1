<?php
/**
* Abstract base class for creating a web page
* @author Nick Korbel <lqqkout13@users.sourceforge.net>
* @version 04-13-06
* @package phpScheduleIt.PageBase
*
* Copyright (C) 2003 - 2007 phpScheduleIt
* License: GPL, see LICENSE
*/

class Page
{
	function printHeaders() {
		die ('Not implemented');
	}
}
?>